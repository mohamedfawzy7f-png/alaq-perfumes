-- Run after schema.sql. Powers the homepage newsletter form.
create table public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text unique not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and length(email) <= 200),
  created_at timestamptz default now());
alter table public.newsletter_subscribers enable row level security;
create policy "anyone can subscribe" on public.newsletter_subscribers for insert to anon, authenticated with check (true);
create policy "admin reads subscribers" on public.newsletter_subscribers for select using (public.is_admin());
create policy "admin deletes subscribers" on public.newsletter_subscribers for delete using (public.is_admin());
