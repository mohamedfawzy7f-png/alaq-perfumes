-- ALAQ schema + RLS. Run once in Supabase → SQL Editor.
create extension if not exists pgcrypto;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text, phone text,
  role text not null default 'customer' check (role in ('customer','admin')),
  created_at timestamptz default now()
);
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, name_ar text not null, name_en text not null,
  sort_order int default 0, is_active boolean default true
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name_ar text not null, name_en text not null,
  description_ar text, description_en text,
  category_id uuid references public.categories(id) on delete set null,
  gender text not null default 'unisex' check (gender in ('men','women','unisex')),
  fragrance_type text,
  price numeric(10,2) not null check (price >= 0),
  sale_price numeric(10,2) check (sale_price is null or sale_price < price),
  sizes int[] not null default '{50}',
  stock int not null default 0 check (stock >= 0),
  images text[] not null default '{}',
  is_featured boolean default false, is_bestseller boolean default false,
  is_new boolean default false, is_exclusive boolean default false,
  is_active boolean default true,
  created_at timestamptz default now()
);
create table public.customers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  full_name text not null, phone text unique not null,
  governorate text, city text, address text,
  created_at timestamptz default now()
);
create sequence public.order_seq start 1001;
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null default ('ALQ-' || nextval('public.order_seq')),
  customer_id uuid references public.customers(id),
  full_name text not null, phone text not null,
  governorate text not null, city text not null, address text not null, notes text,
  subtotal numeric(10,2) not null, delivery_fee numeric(10,2) not null, total numeric(10,2) not null,
  payment_method text not null default 'cod' check (payment_method = 'cod'),
  status text not null default 'pending'
    check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  created_at timestamptz default now(), updated_at timestamptz default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  name_ar text not null, name_en text not null,
  size_ml int, unit_price numeric(10,2) not null, quantity int not null check (quantity > 0)
);
create table public.store_settings (
  key text primary key, value jsonb not null, updated_at timestamptz default now()
);
insert into public.store_settings(key,value) values
  ('delivery_fee','60'), ('brand','{"name_ar":"أَلَق","name_en":"ALAQ"}'),
  ('banners','[]'), ('offers','[]');

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin') $$;

-- Every signup is a CUSTOMER. Admin is granted only by SQL (see README).
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as
$$ begin
  insert into public.profiles(id, full_name) values (new.id, new.raw_user_meta_data->>'full_name');
  return new; end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.protect_role() returns trigger
language plpgsql security definer set search_path = public as
$$ begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'role change not allowed'; end if;
  return new; end $$;
create trigger profiles_protect_role before update on public.profiles
  for each row execute function public.protect_role();

-- Order placement: validation and pricing happen server-side.
create or replace function public.place_order(payload jsonb) returns text
language plpgsql security definer set search_path = public as
$$
declare
  c jsonb := payload->'customer'; it jsonb; p public.products;
  v_items jsonb := payload->'items'; v_sub numeric := 0; v_fee numeric;
  v_cust uuid; v_order public.orders; v_qty int; v_price numeric;
begin
  if jsonb_typeof(v_items) <> 'array' or jsonb_array_length(v_items) not between 1 and 20 then
    raise exception 'invalid items'; end if;
  if coalesce(c->>'phone','') !~ '^01[0-25][0-9]{8}$' then raise exception 'invalid phone'; end if;
  if length(trim(coalesce(c->>'full_name',''))) < 3 or length(c->>'full_name') > 100
     or length(coalesce(c->>'governorate','')) < 2 or length(coalesce(c->>'city','')) < 2
     or length(trim(coalesce(c->>'address',''))) < 8 or length(c->>'address') > 300
     or length(coalesce(c->>'notes','')) > 500 then
    raise exception 'invalid customer data'; end if;

  select coalesce((value #>> '{}')::numeric, 0) into v_fee from store_settings where key='delivery_fee';

  insert into customers(full_name, phone, governorate, city, address, user_id)
  values (trim(c->>'full_name'), c->>'phone', c->>'governorate', c->>'city', c->>'address', auth.uid())
  on conflict (phone) do update set full_name = excluded.full_name,
    governorate = excluded.governorate, city = excluded.city, address = excluded.address
  returning id into v_cust;

  insert into orders(customer_id, full_name, phone, governorate, city, address, notes,
                     subtotal, delivery_fee, total)
  values (v_cust, trim(c->>'full_name'), c->>'phone', c->>'governorate', c->>'city',
          c->>'address', nullif(c->>'notes',''), 0, v_fee, 0)
  returning * into v_order;

  for it in select * from jsonb_array_elements(v_items) loop
    v_qty := (it->>'quantity')::int;
    if v_qty not between 1 and 10 then raise exception 'invalid quantity'; end if;
    select * into p from products where id = (it->>'product_id')::uuid and is_active for update;
    if not found then raise exception 'product unavailable'; end if;
    if p.stock < v_qty then raise exception 'insufficient stock: %', p.name_en; end if;
    v_price := coalesce(p.sale_price, p.price);
    update products set stock = stock - v_qty where id = p.id;
    insert into order_items(order_id, product_id, name_ar, name_en, size_ml, unit_price, quantity)
    values (v_order.id, p.id, p.name_ar, p.name_en, nullif(it->>'size_ml','')::int, v_price, v_qty);
    v_sub := v_sub + v_price * v_qty;
  end loop;

  update orders set subtotal = v_sub, total = v_sub + v_fee where id = v_order.id;
  return v_order.order_number;
end $$;
grant execute on function public.place_order(jsonb) to anon, authenticated;

-- Tracking needs order number AND phone.
create or replace function public.track_order(p_number text, p_phone text) returns jsonb
language sql stable security definer set search_path = public as
$$ select jsonb_build_object('order_number', o.order_number, 'status', o.status,
         'total', o.total, 'created_at', o.created_at,
         'items', (select coalesce(jsonb_agg(jsonb_build_object('name_ar',i.name_ar,'name_en',i.name_en,
                   'quantity',i.quantity,'unit_price',i.unit_price)), '[]') from order_items i where i.order_id=o.id))
   from orders o where o.order_number = p_number and o.phone = p_phone $$;
grant execute on function public.track_order(text, text) to anon, authenticated;

create or replace function public.restock_on_cancel() returns trigger
language plpgsql security definer set search_path = public as
$$ begin
  new.updated_at := now();
  if new.status = 'cancelled' and old.status <> 'cancelled' then
    update products p set stock = p.stock + i.quantity
    from order_items i where i.order_id = new.id and i.product_id = p.id; end if;
  return new; end $$;
create trigger orders_status_change before update on public.orders
  for each row execute function public.restock_on_cancel();

-- Row Level Security
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.store_settings enable row level security;

create policy "own profile read" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "own profile update" on public.profiles for update using (id = auth.uid() or public.is_admin());
create policy "public read categories" on public.categories for select using (is_active or public.is_admin());
create policy "admin write categories" on public.categories for all using (public.is_admin()) with check (public.is_admin());
create policy "public read products" on public.products for select using (is_active or public.is_admin());
create policy "admin write products" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "public read settings" on public.store_settings for select using (true);
create policy "admin write settings" on public.store_settings for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all orders" on public.orders for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all order_items" on public.order_items for all using (public.is_admin()) with check (public.is_admin());
create policy "admin all customers" on public.customers for all using (public.is_admin()) with check (public.is_admin());
create policy "own customer read" on public.customers for select using (user_id = auth.uid());
create policy "own orders read" on public.orders for select using (
  customer_id in (select id from public.customers where user_id = auth.uid()));

alter publication supabase_realtime add table public.orders;

insert into storage.buckets(id, name, public) values ('product-images','product-images', true)
  on conflict do nothing;
create policy "public read images" on storage.objects for select using (bucket_id = 'product-images');
create policy "admin upload images" on storage.objects for insert with check (bucket_id='product-images' and public.is_admin());
create policy "admin update images" on storage.objects for update using (bucket_id='product-images' and public.is_admin());
create policy "admin delete images" on storage.objects for delete using (bucket_id='product-images' and public.is_admin());
