# ALAQ Perfumes — luxury e-commerce (React + Vite + TS + Tailwind + Supabase)

## Status
Storefront and admin dashboard are implemented. **Not yet built or run** (no network where it was written): run `npm install && npm run build` and fix any reported error before deploying.

## Setup
1. Download/unzip, then `npm install`.
2. Create a project at supabase.com → SQL Editor → run `supabase/schema.sql`, then `supabase/migration_002_newsletter.sql`.
3. Copy `.env.example` to `.env`; fill URL and **anon** key (Project Settings → API). Never use the service_role key.
4. First admin: sign up through the site (or Supabase → Authentication → Add user), then in SQL Editor run:
   `update public.profiles set role='admin' where id=(select id from auth.users where email='YOU@EMAIL');`
   Self-signup can never grant admin (trigger + RLS).
5. `npm run dev` to test locally; `npm run build` for production.
6. GitHub: push to `main`; repo → Settings → Pages → Source: GitHub Actions; add secrets
   `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`. The workflow deploys automatically.
7. Test from another phone: open the Pages URL, place a COD order, watch it appear in /#/admin.

## Security design
- Prices, stock and delivery fee are computed in the database (`place_order`); the client cannot set them.
- Orders and customers are unreadable to the public; tracking needs order number + phone.
- Admin-only writes on products, orders, settings, and image storage.

## Using the store
- Admin lives at `/#/admin` (sign in at `/#/admin/login`). Add categories in Settings first, then products.
- Home sections fill from product flags (Featured, Best seller, New, Exclusive) and gender.
- Offers, banners and reviews are entered in Settings; sections hide when empty.
- If email confirmation is on in Supabase Auth, customers must confirm before first sign in (turn it off under Authentication → Providers → Email for testing).
- `public/logo.png` has a white background, so it is shown on an ivory card. Replace it with a transparent PNG for use directly on black.

## Upload to GitHub and deploy
1. Create an empty repository on github.com (do not add a README).
2. In this folder: `git init && git add . && git commit -m "ALAQ" && git branch -M main && git remote add origin https://github.com/YOU/REPO.git && git push -u origin main`
   (`.gitignore` already keeps `.env` and `node_modules` out of the repo.)
3. Repo → Settings → Secrets and variables → Actions → add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
4. Repo → Settings → Pages → Source: **GitHub Actions**. The push triggers the build; the site appears at `https://YOU.github.io/REPO/`.
5. Supabase → Authentication → URL Configuration → set Site URL to that address, so confirmation emails return to your site.
6. Test from another phone: open the URL, add a perfume to the cart, place a COD order, then watch it appear in `/#/admin/orders` on your computer.

The anon key is designed to be public; security comes from the RLS policies in `schema.sql`. Never use the service_role key anywhere in this project.
