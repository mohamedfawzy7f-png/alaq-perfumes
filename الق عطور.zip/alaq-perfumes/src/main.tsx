import React from 'react'
import ReactDOM from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import './index.css'
import App from './App'
import { Providers } from './lib/context'
ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><HashRouter><Providers><App /></Providers></HashRouter></React.StrictMode>)
