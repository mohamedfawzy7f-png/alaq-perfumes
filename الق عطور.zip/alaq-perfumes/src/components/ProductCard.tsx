import { Link } from 'react-router-dom'
import { Heart, Droplet } from 'lucide-react'
import { useApp } from '../lib/context'
export default function ProductCard({ p }: { p: any }) {
  const { L, tr, money, wish, toggleWish } = useApp(), on = wish.includes(p.id)
  return <div className="group">
    <div className="relative aspect-[4/5] rounded-xl glass overflow-hidden">
      <Link to={`/product/${p.slug}`} className="absolute inset-0">
        {p.images?.[0] ? <img src={p.images[0]} alt={L(p, 'name')} loading="lazy" className="w-full h-full object-cover transition duration-700 group-hover:scale-105" />
          : <div className="w-full h-full grid place-items-center text-champagne-gold/40"><Droplet size={44} /></div>}</Link>
      <button onClick={() => toggleWish(p.id)} aria-label="wishlist" className="absolute top-3 end-3 w-9 h-9 rounded-full bg-black/50 backdrop-blur grid place-items-center">
        <Heart size={17} className={on ? 'fill-champagne-gold text-champagne-gold' : ''} /></button>
      {p.sale_price && <span className="absolute top-3 start-3 text-xs bg-champagne-gold text-black px-2.5 py-1 rounded-full">{tr('خصم', 'Sale')}</span>}
      {p.stock <= 0 && <span className="absolute bottom-3 start-3 text-xs bg-black/70 px-2.5 py-1 rounded-full">{tr('نفد المخزون', 'Sold out')}</span>}
    </div>
    <Link to={`/product/${p.slug}`} className="block mt-4">
      <div className="font-display text-xl">{L(p, 'name')}</div>
      <div className="text-sm text-white/50 mt-1">{p.fragrance_type}</div>
      <div className="mt-2 text-champagne-gold">{money(p.sale_price ?? p.price)}
        {p.sale_price && <span className="text-white/40 line-through text-sm ms-2">{money(p.price)}</span>}</div></Link></div>
}
