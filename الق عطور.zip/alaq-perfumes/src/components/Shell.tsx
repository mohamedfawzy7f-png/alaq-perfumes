import { useEffect, useState } from 'react'
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { Heart, Menu, Search, ShoppingBag, User, X } from 'lucide-react'
import { useApp } from '../lib/context'
import { configured } from '../lib/supabase'

export const Wordmark = ({ size = 'text-2xl' }: { size?: string }) =>
  <Link to="/" className="flex items-baseline gap-3 text-champagne-gold">
    <span className={`font-display ${size} leading-none`} style={{ fontFamily: 'var(--font-arabic-display)' }}>أَلَق</span>
    <span className="text-[11px] tracking-[0.5em] text-gold-soft/80">ALAQ</span></Link>

export default function Shell() {
  const { tr, lang, setLang, cart, wish, user, L, settings } = useApp()
  const [open, setOpen] = useState(false), [sOpen, setSOpen] = useState(false), [q, setQ] = useState('')
  const loc = useLocation(), nav = useNavigate()
  useEffect(() => { setOpen(false); window.scrollTo(0, 0) }, [loc.pathname])
  const count = cart.reduce((a: number, i: any) => a + i.qty, 0)
  const links = [['/shop', tr('المتجر', 'Shop')], ['/shop?g=men', tr('رجالي', 'Men')], ['/shop?g=women', tr('نسائي', 'Women')],
    ['/shop?g=unisex', tr('للجنسين', 'Unisex')], ['/shop?x=1', tr('الحصرية', 'Exclusive')], ['/track', tr('تتبع الطلب', 'Track order')]]
  const offer = (settings.offers || [])[0]
  const search = (e: any) => { e.preventDefault(); nav('/shop?q=' + encodeURIComponent(q)); setSOpen(false) }
  return <div className="min-h-screen bg-carbon-black text-ivory">
    {!configured && <div className="bg-red-900/60 text-center text-sm py-2 px-4">Supabase is not configured. Copy .env.example to .env and add your keys.</div>}
    {offer && <div className="bg-champagne-gold text-carbon-black text-center text-sm py-2 px-4">{L(offer, 'text')}</div>}
    <header className="sticky top-0 z-40 bg-carbon-black/75 backdrop-blur-xl border-b border-white/10">
      <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between gap-6">
        <button className="lg:hidden" onClick={() => setOpen(true)} aria-label="menu"><Menu /></button>
        <Wordmark />
        <nav className="hidden lg:flex gap-7 text-[15px] text-white/70">
          {links.map(([to, l]) => <NavLink key={to} to={to} className="hover:text-champagne-gold transition">{l}</NavLink>)}</nav>
        <div className="flex items-center gap-4">
          <button onClick={() => setSOpen(!sOpen)} aria-label="search"><Search size={20} /></button>
          <Link to="/wishlist" className="relative hidden sm:block" aria-label="wishlist"><Heart size={20} />
            {wish.length > 0 && <span className="absolute -top-2 -end-2 text-[10px] bg-champagne-gold text-black rounded-full w-4 h-4 grid place-items-center">{wish.length}</span>}</Link>
          <Link to="/login" aria-label="account" className="hidden sm:block"><User size={20} className={user ? 'text-champagne-gold' : ''} /></Link>
          <Link to="/cart" className="relative" aria-label="cart"><ShoppingBag size={20} />
            {count > 0 && <span className="absolute -top-2 -end-2 text-[10px] bg-champagne-gold text-black rounded-full w-4 h-4 grid place-items-center">{count}</span>}</Link>
          <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="text-sm border border-white/20 rounded-full px-3 py-1 hover:border-champagne-gold">{lang === 'ar' ? 'EN' : 'عربي'}</button>
        </div></div>
      {sOpen && <form onSubmit={search} className="max-w-7xl mx-auto px-5 pb-4"><input autoFocus value={q} onChange={e => setQ(e.target.value)}
        placeholder={tr('ابحث عن عطر...', 'Search perfumes...')} className="w-full bg-charcoal-shale border border-white/15 rounded-full px-5 py-3 outline-none focus:border-champagne-gold" /></form>}
    </header>
    {open && <div className="fixed inset-0 z-50 bg-carbon-black p-6 flex flex-col">
      <div className="flex justify-between items-center mb-10"><Wordmark /><button onClick={() => setOpen(false)}><X /></button></div>
      <nav className="flex flex-col gap-6 text-2xl font-display">
        {links.map(([to, l]) => <Link key={to} to={to}>{l}</Link>)}
        <Link to="/wishlist">{tr('المفضلة', 'Wishlist')} ({wish.length})</Link>
        <Link to="/login">{user ? tr('حسابي', 'My account') : tr('تسجيل الدخول', 'Sign in')}</Link></nav></div>}
    <main><Outlet /></main>
    <footer className="border-t border-white/10 mt-28 py-14 px-5">
      <div className="max-w-7xl mx-auto grid gap-10 md:grid-cols-3">
        <div><Wordmark size="text-4xl" /><p className="text-white/50 text-sm mt-4 max-w-xs leading-7">{tr('عطور فاخرة من مصر.', 'Luxury fragrances from Egypt.')}</p></div>
        <div className="flex flex-col gap-3 text-white/60 text-sm">{links.map(([to, l]) => <Link key={to} to={to} className="hover:text-champagne-gold">{l}</Link>)}</div>
        <div className="text-sm text-white/50 leading-7">{tr('الدفع عند الاستلام. التوصيل لجميع محافظات مصر.', 'Cash on delivery. Delivery across all Egyptian governorates.')}
          <div className="mt-4">© {new Date().getFullYear()} ALAQ</div></div></div></footer>
  </div>
}
