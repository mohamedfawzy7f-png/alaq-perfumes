import { useState } from 'react'
import { Link, NavLink, Navigate, Outlet } from 'react-router-dom'
import { LayoutDashboard, Package, ShoppingCart, Users, Settings, LogOut, Store } from 'lucide-react'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { gold, ghost, inp, Spinner, ErrorBox } from '../lib/ui'

export function AdminLogin() {
  const { tr, user, isAdmin, authLoading } = useApp(), [email, setEmail] = useState(''), [pw, setPw] = useState(''), [err, setErr] = useState('')
  if (!authLoading && user && isAdmin) return <Navigate to="/admin" replace />
  const go = async (e: any) => {
    e.preventDefault(); setErr('')
    const { data, error } = await supabase.auth.signInWithPassword({ email, password: pw }); if (error) return setErr(error.message)
    const { data: p } = await supabase.from('profiles').select('role').eq('id', data.user.id).maybeSingle()
    if (p?.role !== 'admin') { await supabase.auth.signOut(); setErr(tr('هذا الحساب غير مصرح له بدخول لوحة التحكم.', 'This account is not authorized for the dashboard.')) }
  }
  return <div className="min-h-screen bg-carbon-black text-ivory grid place-items-center px-5"><form onSubmit={go} className="glass rounded-2xl p-8 w-full max-w-sm space-y-4">
    <h1 className="font-display text-3xl text-champagne-gold">{tr('دخول الإدارة', 'Admin sign in')}</h1>
    <input required type="email" dir="ltr" className={inp} placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} />
    <input required type="password" dir="ltr" className={inp} placeholder="Password" value={pw} onChange={e => setPw(e.target.value)} />
    <ErrorBox msg={err} /><button className={gold + ' w-full'}>{tr('دخول', 'Sign in')}</button></form></div>
}

export default function AdminLayout() {
  const { tr, user, isAdmin, authLoading, lang, setLang } = useApp()
  if (authLoading) return <div className="min-h-screen bg-carbon-black"><Spinner /></div>
  if (!user) return <Navigate to="/admin/login" replace />
  if (!isAdmin) return <div className="min-h-screen bg-carbon-black text-ivory grid place-items-center text-center px-5"><div>
    <p className="mb-6">{tr('ليس لديك صلاحية الوصول.', 'You do not have access.')}</p><div className="flex gap-3 justify-center"><Link to="/" className={gold}>{tr('المتجر', 'Store')}</Link>
    <button className={ghost} onClick={() => supabase.auth.signOut()}>{tr('تسجيل الخروج', 'Sign out')}</button></div></div></div>
  const items = [['/admin', LayoutDashboard, tr('نظرة عامة', 'Overview'), true], ['/admin/products', Package, tr('المنتجات', 'Products')], ['/admin/orders', ShoppingCart, tr('الطلبات', 'Orders')],
    ['/admin/customers', Users, tr('العملاء', 'Customers')], ['/admin/settings', Settings, tr('الإعدادات', 'Settings')]] as any[]
  return <div className="min-h-screen bg-carbon-black text-ivory md:flex">
    <aside className="md:w-60 md:min-h-screen border-b md:border-b-0 md:border-e border-white/10 p-4 md:p-6 md:sticky md:top-0 md:h-screen flex md:flex-col gap-4 items-center md:items-stretch overflow-x-auto">
      <div className="hidden md:block font-display text-3xl text-champagne-gold mb-6" style={{ fontFamily: 'var(--font-arabic-display)' }}>أَلَق <span className="text-[11px] tracking-[0.4em]">ADMIN</span></div>
      <nav className="flex md:flex-col gap-1 flex-1">{items.map(([to, Icon, l, end]) => <NavLink key={to} to={to} end={end}
        className={({ isActive }) => `flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm whitespace-nowrap ${isActive ? 'bg-champagne-gold/15 text-champagne-gold' : 'text-white/65 hover:bg-white/5'}`}><Icon size={17} />{l}</NavLink>)}</nav>
      <div className="flex md:flex-col gap-2 text-sm">
        <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="px-4 py-2 rounded-lg border border-white/15">{lang === 'ar' ? 'English' : 'عربي'}</button>
        <Link to="/" className="px-4 py-2 flex gap-2 items-center text-white/65 whitespace-nowrap"><Store size={16} />{tr('المتجر', 'Store')}</Link>
        <button onClick={() => supabase.auth.signOut()} className="px-4 py-2 flex gap-2 items-center text-white/65 whitespace-nowrap"><LogOut size={16} />{tr('خروج', 'Sign out')}</button></div></aside>
    <main className="flex-1 p-5 md:p-10 min-w-0"><Outlet /></main></div>
}
