import { useEffect } from 'react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { useApp, STATUS_LABEL } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, Spinner, ErrorBox } from '../lib/ui'

export default function Dashboard() {
  const { tr, money, lang } = useApp()
  const { data, loading, error, reload } = useAsync(async () => {
    const [o, p, c] = await Promise.all([
      supabase.from('orders').select('id,order_number,full_name,total,status,created_at').order('created_at', { ascending: false }).limit(2000),
      supabase.from('products').select('id', { count: 'exact', head: true }), supabase.from('customers').select('id', { count: 'exact', head: true })])
    if (o.error) throw o.error
    return { orders: o.data || [], products: p.count || 0, customers: c.count || 0 } }, [])
  useEffect(() => { const ch = supabase.channel('dash-orders').on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => reload()).subscribe(); return () => { supabase.removeChannel(ch) } }, [])
  if (loading && !data) return <Spinner />
  if (!data) return <ErrorBox msg={error} />
  const valid = data.orders.filter((o: any) => o.status !== 'cancelled'), revenue = valid.reduce((a: number, o: any) => a + Number(o.total), 0)
  const days = Array.from({ length: 14 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - (13 - i)); return d })
  const key = (d: Date) => `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
  const chart = days.map(d => ({ day: d.toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', { day: 'numeric', month: 'short' }),
    revenue: valid.filter((o: any) => key(new Date(o.created_at)) === key(d)).reduce((a: number, o: any) => a + Number(o.total), 0) }))
  const cards = [[tr('الإيرادات (دون الملغي)', 'Revenue (excl. cancelled)'), money(revenue)], [tr('الطلبات', 'Orders'), data.orders.length], [tr('المنتجات', 'Products'), data.products],
    [tr('العملاء', 'Customers'), data.customers], [tr('طلبات معلقة', 'Pending orders'), data.orders.filter((o: any) => o.status === 'pending').length]]
  return <div><h1 className="font-display text-4xl mb-8">{tr('نظرة عامة', 'Overview')}</h1>
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">{cards.map(([l, v], i) => <div key={i} className="glass rounded-xl p-5"><div className="text-xs text-white/50">{l}</div><div className="text-2xl text-champagne-gold mt-2">{v}</div></div>)}</div>
    <div className="glass rounded-xl p-5 mt-6"><div className="mb-4 text-white/70">{tr('الإيرادات آخر 14 يوماً', 'Revenue, last 14 days')}</div>
      <div dir="ltr" className="h-64"><ResponsiveContainer><AreaChart data={chart}><CartesianGrid stroke="rgba(255,255,255,.08)" vertical={false} />
        <XAxis dataKey="day" stroke="#888" fontSize={11} /><YAxis stroke="#888" fontSize={11} width={50} />
        <Tooltip contentStyle={{ background: '#1b1a18', border: '1px solid #c9a96e55', borderRadius: 8 }} formatter={(v: any) => money(v)} />
        <Area type="monotone" dataKey="revenue" stroke="#c9a96e" fill="#c9a96e" fillOpacity={0.18} /></AreaChart></ResponsiveContainer></div></div>
    <div className="glass rounded-xl p-5 mt-6 overflow-x-auto"><div className="mb-4 text-white/70">{tr('أحدث الطلبات', 'Recent orders')}</div>
      <table className="w-full text-sm min-w-[480px]"><tbody>{data.orders.slice(0, 8).map((o: any) => <tr key={o.id} className="border-t border-white/10">
        <td className="py-3 text-champagne-gold" dir="ltr">{o.order_number}</td><td>{o.full_name}</td><td>{money(o.total)}</td><td>{STATUS_LABEL[o.status][lang === 'ar' ? 0 : 1]}</td></tr>)}</tbody></table></div></div>
}
