import { useEffect, useState } from 'react'
import { useApp, STATUSES, STATUS_LABEL } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, inp, Modal, Spinner, ErrorBox } from '../lib/ui'

export function OrderDetail({ order, onClose, onChange }: any) {
  const { tr, L, money, lang } = useApp(), [o, setO] = useState(order), [err, setErr] = useState('')
  const { data: items } = useAsync(async () => (await supabase.from('order_items').select('*').eq('order_id', order.id)).data || [], [order.id])
  const setStatus = async (s: string) => { const { error } = await supabase.from('orders').update({ status: s }).eq('id', o.id); if (error) return setErr(error.message); setO({ ...o, status: s }); onChange?.() }
  return <Modal title={o.order_number} onClose={onClose}><div className="space-y-4 text-sm">
    <div className="grid sm:grid-cols-2 gap-3"><div><div className="text-white/45">{tr('العميل', 'Customer')}</div>{o.full_name}</div><div><div className="text-white/45">{tr('الهاتف', 'Phone')}</div><a href={`tel:${o.phone}`} dir="ltr" className="text-champagne-gold">{o.phone}</a></div>
      <div><div className="text-white/45">{tr('المحافظة / المدينة', 'Governorate / City')}</div>{o.governorate} / {o.city}</div><div><div className="text-white/45">{tr('التاريخ', 'Placed')}</div>{new Date(o.created_at).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</div></div>
    <div><div className="text-white/45">{tr('العنوان', 'Address')}</div>{o.address}</div>{o.notes && <div><div className="text-white/45">{tr('ملاحظات', 'Notes')}</div>{o.notes}</div>}
    <div className="border-t border-white/10 pt-3">{(items || []).map((i: any) => <div key={i.id} className="flex justify-between py-1"><span>{L(i, 'name')} · {i.size_ml}{tr('مل', 'ml')} × {i.quantity}</span><span>{money(i.unit_price * i.quantity)}</span></div>)}
      <div className="flex justify-between text-white/60 pt-2"><span>{tr('التوصيل', 'Delivery')}</span><span>{money(o.delivery_fee)}</span></div><div className="flex justify-between text-lg text-champagne-gold pt-1"><span>{tr('الإجمالي (عند الاستلام)', 'Total (COD)')}</span><span>{money(o.total)}</span></div></div>
    <div><div className="text-white/45 mb-2">{tr('الحالة', 'Status')}</div><div className="flex flex-wrap gap-2">{STATUSES.map(s => <button key={s} onClick={() => setStatus(s)}
      className={`px-4 py-2 rounded-full border ${o.status === s ? 'border-champagne-gold bg-champagne-gold/15 text-champagne-gold' : 'border-white/20 text-white/65'}`}>{STATUS_LABEL[s][lang === 'ar' ? 0 : 1]}</button>)}</div></div>
    <ErrorBox msg={err} /><div className="text-white/40 text-xs">{tr('آخر تحديث', 'Last updated')}: {new Date(o.updated_at).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</div></div></Modal>
}

export default function Orders() {
  const { tr, money, lang } = useApp(), [q, setQ] = useState(''), [st, setSt] = useState(''), [sel, setSel] = useState<any>(null)
  const { data, loading, error, reload } = useAsync(async () => { const { data, error } = await supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(1000); if (error) throw error; return data }, [])
  useEffect(() => { const ch = supabase.channel('orders-list').on('postgres_changes', { event: '*', schema: 'public', table: 'orders' }, () => reload()).subscribe(); return () => { supabase.removeChannel(ch) } }, [])
  const list = (data || []).filter((o: any) => (!st || o.status === st) && (!q || [o.order_number, o.full_name, o.phone].join(' ').toLowerCase().includes(q.toLowerCase())))
  return <div><h1 className="font-display text-4xl mb-8">{tr('الطلبات', 'Orders')}</h1>
    <div className="grid sm:grid-cols-2 gap-3 mb-6"><input className={inp} placeholder={tr('بحث بالرقم أو الاسم أو الهاتف', 'Search number, name or phone')} value={q} onChange={e => setQ(e.target.value)} />
      <select className={inp} value={st} onChange={e => setSt(e.target.value)}><option value="">{tr('كل الحالات', 'All statuses')}</option>{STATUSES.map(s => <option key={s} value={s}>{STATUS_LABEL[s][lang === 'ar' ? 0 : 1]}</option>)}</select></div>
    <ErrorBox msg={error} />{loading && !data ? <Spinner /> : !list.length ? <p className="text-white/50">{tr('لا توجد طلبات.', 'No orders.')}</p> :
      <div className="glass rounded-xl overflow-x-auto"><table className="w-full text-sm min-w-[640px]"><tbody>{list.map((o: any) => <tr key={o.id} onClick={() => setSel(o)} className="border-b border-white/10 last:border-0 cursor-pointer hover:bg-white/5">
        <td className="p-4 text-champagne-gold" dir="ltr">{o.order_number}</td><td>{o.full_name}</td><td dir="ltr">{o.phone}</td><td>{money(o.total)}</td><td>{STATUS_LABEL[o.status][lang === 'ar' ? 0 : 1]}</td>
        <td className="text-white/45">{new Date(o.created_at).toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US')}</td></tr>)}</tbody></table></div>}
    {sel && <OrderDetail order={sel} onClose={() => setSel(null)} onChange={reload} />}</div>
}
