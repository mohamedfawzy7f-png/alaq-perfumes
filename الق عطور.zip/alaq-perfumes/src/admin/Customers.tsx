import { useState } from 'react'
import { useApp, STATUS_LABEL } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, inp, Modal, Spinner, ErrorBox } from '../lib/ui'
import { OrderDetail } from './Orders'

export default function Customers() {
  const { tr, money, lang } = useApp(), [q, setQ] = useState(''), [sel, setSel] = useState<any>(null), [ord, setOrd] = useState<any>(null)
  const { data, loading, error } = useAsync(async () => {
    const [c, o] = await Promise.all([supabase.from('customers').select('*').order('created_at', { ascending: false }), supabase.from('orders').select('customer_id,total,status')])
    if (c.error) throw c.error
    const agg: any = {}; (o.data || []).forEach((x: any) => { const a = agg[x.customer_id] ||= { n: 0, t: 0 }; a.n++; if (x.status !== 'cancelled') a.t += Number(x.total) })
    return (c.data || []).map((x: any) => ({ ...x, orders: agg[x.id]?.n || 0, spent: agg[x.id]?.t || 0 })) }, [])
  const { data: history } = useAsync(async () => sel ? (await supabase.from('orders').select('*').eq('customer_id', sel.id).order('created_at', { ascending: false })).data || [] : [], [sel?.id])
  const list = (data || []).filter((c: any) => !q || [c.full_name, c.phone].join(' ').toLowerCase().includes(q.toLowerCase()))
  return <div><h1 className="font-display text-4xl mb-8">{tr('العملاء', 'Customers')}</h1><input className={inp + ' mb-6 max-w-md'} placeholder={tr('بحث بالاسم أو الهاتف', 'Search name or phone')} value={q} onChange={e => setQ(e.target.value)} />
    <ErrorBox msg={error} />{loading ? <Spinner /> : !list.length ? <p className="text-white/50">{tr('لا يوجد عملاء بعد.', 'No customers yet.')}</p> :
      <div className="glass rounded-xl overflow-x-auto"><table className="w-full text-sm min-w-[600px]"><tbody>{list.map((c: any) => <tr key={c.id} onClick={() => setSel(c)} className="border-b border-white/10 last:border-0 cursor-pointer hover:bg-white/5">
        <td className="p-4">{c.full_name}</td><td dir="ltr" className="text-champagne-gold">{c.phone}</td><td>{c.governorate} / {c.city}</td><td>{c.orders} {tr('طلب', 'orders')}</td><td>{money(c.spent)}</td></tr>)}</tbody></table></div>}
    {sel && !ord && <Modal title={sel.full_name} onClose={() => setSel(null)}><div className="text-sm space-y-2"><div dir="ltr" className="text-champagne-gold">{sel.phone}</div><div>{sel.governorate} / {sel.city}</div><div className="text-white/60">{sel.address}</div>
      <div className="pt-4 border-t border-white/10 mt-4 text-white/45">{tr('سجل الطلبات', 'Order history')}</div>
      {(history || []).map((o: any) => <button key={o.id} onClick={() => setOrd(o)} className="w-full flex justify-between py-2 border-b border-white/10 text-start"><span dir="ltr" className="text-champagne-gold">{o.order_number}</span><span>{money(o.total)}</span><span>{STATUS_LABEL[o.status][lang === 'ar' ? 0 : 1]}</span></button>)}</div></Modal>}
    {ord && <OrderDetail order={ord} onClose={() => setOrd(null)} />}</div>
}
