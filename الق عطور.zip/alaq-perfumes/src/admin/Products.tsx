import { useState } from 'react'
import { Pencil, Trash2, Plus, X } from 'lucide-react'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, gold, ghost, inp, Field, Modal, Spinner, ErrorBox, slugify } from '../lib/ui'

const blank = { name_ar: '', name_en: '', slug: '', description_ar: '', description_en: '', category_id: '', gender: 'unisex', fragrance_type: '', price: '', sale_price: '', sizes: '50, 100', stock: '0',
  images: [] as string[], is_featured: false, is_bestseller: false, is_new: false, is_exclusive: false, is_active: true }

export default function Products() {
  const { tr, L, money } = useApp(), [edit, setEdit] = useState<any>(null), [err, setErr] = useState(''), [busy, setBusy] = useState(false)
  const { data, loading, error, reload } = useAsync(async () => {
    const [p, c] = await Promise.all([supabase.from('products').select('*').order('created_at', { ascending: false }), supabase.from('categories').select('*').order('sort_order')])
    if (p.error) throw p.error; return { products: p.data || [], cats: c.data || [] } }, [])
  const open = (p?: any) => { setErr(''); setEdit(p ? { ...p, category_id: p.category_id || '', sale_price: p.sale_price ?? '', sizes: (p.sizes || []).join(', '), price: String(p.price), stock: String(p.stock) } : { ...blank }) }
  const set = (k: string, v: any) => setEdit((e: any) => ({ ...e, [k]: v }))
  const upload = async (files: FileList | null) => {
    if (!files) return; setBusy(true); setErr(''); const urls: string[] = []
    for (const f of Array.from(files)) {
      const path = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${(f.name.split('.').pop() || 'jpg').toLowerCase()}`
      const { error } = await supabase.storage.from('product-images').upload(path, f, { contentType: f.type }); if (error) { setErr(error.message); break }
      urls.push(supabase.storage.from('product-images').getPublicUrl(path).data.publicUrl) }
    set('images', [...edit.images, ...urls]); setBusy(false)
  }
  const save = async (e: any) => {
    e.preventDefault(); setErr('')
    const sizes = edit.sizes.split(',').map((s: string) => parseInt(s.trim())).filter((n: number) => n > 0)
    const price = Number(edit.price), sale = edit.sale_price === '' ? null : Number(edit.sale_price)
    if (!sizes.length) return setErr(tr('أدخل حجماً واحداً على الأقل.', 'Enter at least one size.'))
    if (sale !== null && sale >= price) return setErr(tr('سعر الخصم يجب أن يكون أقل من السعر.', 'Sale price must be lower than the price.'))
    const row: any = { name_ar: edit.name_ar, name_en: edit.name_en, slug: slugify(edit.slug || edit.name_en), description_ar: edit.description_ar, description_en: edit.description_en,
      category_id: edit.category_id || null, gender: edit.gender, fragrance_type: edit.fragrance_type, price, sale_price: sale, sizes, stock: parseInt(edit.stock) || 0, images: edit.images,
      is_featured: edit.is_featured, is_bestseller: edit.is_bestseller, is_new: edit.is_new, is_exclusive: edit.is_exclusive, is_active: edit.is_active }
    if (!row.slug) return setErr(tr('أدخل الاسم الإنجليزي لإنشاء الرابط.', 'Enter the English name to build the URL.'))
    const { error } = edit.id ? await supabase.from('products').update(row).eq('id', edit.id) : await supabase.from('products').insert(row)
    if (error) return setErr(error.message); setEdit(null); reload()
  }
  const del = async (p: any) => { if (!confirm(tr('حذف هذا المنتج نهائياً؟', 'Delete this product permanently?'))) return; const { error } = await supabase.from('products').delete().eq('id', p.id); if (error) alert(error.message); reload() }
  const quick = async (p: any, k: string) => { await supabase.from('products').update({ [k]: !p[k] }).eq('id', p.id); reload() }
  const flags: [string, string, string][] = [['is_active', 'مفعّل', 'Active'], ['is_featured', 'مميز', 'Featured'], ['is_bestseller', 'الأكثر مبيعاً', 'Best seller'], ['is_new', 'جديد', 'New'], ['is_exclusive', 'حصري', 'Exclusive']]
  return <div><div className="flex justify-between items-center mb-8"><h1 className="font-display text-4xl">{tr('المنتجات', 'Products')}</h1><button className={gold} onClick={() => open()}><Plus size={16} />{tr('منتج جديد', 'New product')}</button></div>
    <ErrorBox msg={error} />{loading ? <Spinner /> : !data?.products.length ? <p className="text-white/50">{tr('لا توجد منتجات. أضف أول عطر.', 'No products yet. Add your first perfume.')}</p> :
      <div className="glass rounded-xl overflow-x-auto"><table className="w-full text-sm min-w-[720px]"><tbody>{data.products.map((p: any) => <tr key={p.id} className="border-b border-white/10 last:border-0">
        <td className="p-3 w-16">{p.images?.[0] && <img src={p.images[0]} className="w-12 h-14 object-cover rounded" alt="" />}</td>
        <td><div>{L(p, 'name')}</div><div className="text-white/40 text-xs">{p.slug}</div></td><td>{money(p.sale_price ?? p.price)}</td><td>{tr('المخزون', 'Stock')}: {p.stock}</td>
        <td><button onClick={() => quick(p, 'is_active')} className={`text-xs px-3 py-1 rounded-full ${p.is_active ? 'bg-champagne-gold/20 text-champagne-gold' : 'bg-white/10 text-white/50'}`}>{p.is_active ? tr('مفعّل', 'Active') : tr('معطّل', 'Disabled')}</button>
          <button onClick={() => quick(p, 'is_featured')} className={`text-xs px-3 py-1 rounded-full ms-2 ${p.is_featured ? 'bg-champagne-gold/20 text-champagne-gold' : 'bg-white/10 text-white/50'}`}>{tr('مميز', 'Featured')}</button></td>
        <td className="whitespace-nowrap p-3"><button onClick={() => open(p)} className="p-2" aria-label="edit"><Pencil size={16} /></button><button onClick={() => del(p)} className="p-2 text-red-300" aria-label="delete"><Trash2 size={16} /></button></td></tr>)}</tbody></table></div>}
    {edit && <Modal title={edit.id ? tr('تعديل المنتج', 'Edit product') : tr('منتج جديد', 'New product')} onClose={() => setEdit(null)}>
      <form onSubmit={save} className="space-y-4">
        <div className="grid sm:grid-cols-2 gap-4"><Field label={tr('الاسم بالعربية', 'Name (Arabic)')}><input required className={inp} value={edit.name_ar} onChange={e => set('name_ar', e.target.value)} /></Field>
          <Field label={tr('الاسم بالإنجليزية', 'Name (English)')}><input required dir="ltr" className={inp} value={edit.name_en} onChange={e => set('name_en', e.target.value)} /></Field></div>
        <Field label={tr('الوصف بالعربية', 'Description (Arabic)')}><textarea rows={3} className={inp} value={edit.description_ar} onChange={e => set('description_ar', e.target.value)} /></Field>
        <Field label={tr('الوصف بالإنجليزية', 'Description (English)')}><textarea rows={3} dir="ltr" className={inp} value={edit.description_en} onChange={e => set('description_en', e.target.value)} /></Field>
        <div className="grid sm:grid-cols-3 gap-4"><Field label={tr('الفئة', 'Category')}><select className={inp} value={edit.category_id} onChange={e => set('category_id', e.target.value)}><option value="">—</option>{data?.cats.map((c: any) => <option key={c.id} value={c.id}>{L(c, 'name')}</option>)}</select></Field>
          <Field label={tr('النوع', 'Gender')}><select className={inp} value={edit.gender} onChange={e => set('gender', e.target.value)}><option value="men">{tr('رجالي', 'Men')}</option><option value="women">{tr('نسائي', 'Women')}</option><option value="unisex">{tr('للجنسين', 'Unisex')}</option></select></Field>
          <Field label={tr('العائلة العطرية', 'Fragrance type')}><input className={inp} value={edit.fragrance_type} onChange={e => set('fragrance_type', e.target.value)} placeholder="Oud, Floral…" /></Field></div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4"><Field label={tr('السعر', 'Price')}><input required type="number" min="0" step="0.01" className={inp} value={edit.price} onChange={e => set('price', e.target.value)} /></Field>
          <Field label={tr('سعر الخصم', 'Sale price')}><input type="number" min="0" step="0.01" className={inp} value={edit.sale_price} onChange={e => set('sale_price', e.target.value)} /></Field>
          <Field label={tr('المخزون', 'Stock')}><input required type="number" min="0" className={inp} value={edit.stock} onChange={e => set('stock', e.target.value)} /></Field>
          <Field label={tr('الأحجام (مل)', 'Sizes (ml)')}><input dir="ltr" className={inp} value={edit.sizes} onChange={e => set('sizes', e.target.value)} /></Field></div>
        <Field label={tr('الرابط (اختياري)', 'URL slug (optional)')}><input dir="ltr" className={inp} value={edit.slug} onChange={e => set('slug', e.target.value)} placeholder={slugify(edit.name_en)} /></Field>
        <div><div className="text-sm text-white/60 mb-2">{tr('الصور', 'Images')}</div><div className="flex gap-2 flex-wrap mb-2">{edit.images.map((u: string) => <div key={u} className="relative"><img src={u} className="w-20 h-24 object-cover rounded" alt="" />
          <button type="button" onClick={() => set('images', edit.images.filter((x: string) => x !== u))} className="absolute -top-2 -end-2 bg-black rounded-full p-1" aria-label="remove"><X size={12} /></button></div>)}</div>
          <input type="file" accept="image/*" multiple onChange={e => upload(e.target.files)} className="text-sm" />{busy && <span className="text-sm text-champagne-gold ms-2">{tr('جارٍ الرفع...', 'Uploading...')}</span>}</div>
        <div className="flex flex-wrap gap-4 text-sm">{flags.map(([k, a, e]) => <label key={k} className="flex items-center gap-2"><input type="checkbox" checked={edit[k]} onChange={ev => set(k, ev.target.checked)} />{tr(a, e)}</label>)}</div>
        <ErrorBox msg={err} /><div className="flex gap-3"><button disabled={busy} className={gold}>{tr('حفظ', 'Save')}</button><button type="button" className={ghost} onClick={() => setEdit(null)}>{tr('إلغاء', 'Cancel')}</button></div></form></Modal>}</div>
}
