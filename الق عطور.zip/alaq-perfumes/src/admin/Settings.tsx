import { useEffect, useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, gold, ghost, inp, Field, ErrorBox, slugify } from '../lib/ui'

function ListEditor({ k, title, fields, blank }: any) {
  const { tr, settings, reloadSettings } = useApp(), [rows, setRows] = useState<any[]>([]), [msg, setMsg] = useState('')
  useEffect(() => setRows(settings[k] || []), [settings[k]])
  const save = async () => { const { error } = await supabase.from('store_settings').upsert({ key: k, value: rows }); setMsg(error ? error.message : tr('تم الحفظ', 'Saved')); reloadSettings() }
  return <section className="glass rounded-xl p-5 mb-6"><h2 className="font-display text-2xl text-champagne-gold mb-4">{title}</h2>
    {rows.map((r, i) => <div key={i} className="grid sm:grid-cols-2 gap-3 mb-4 pb-4 border-b border-white/10">{fields.map(([f, a, e]: any) => <Field key={f} label={tr(a, e)}><input className={inp} value={r[f] ?? ''} onChange={ev => setRows(rows.map((x, j) => j === i ? { ...x, [f]: ev.target.value } : x))} /></Field>)}
      <button className="text-red-300 text-sm flex gap-1 items-center" onClick={() => setRows(rows.filter((_, j) => j !== i))}><Trash2 size={14} />{tr('حذف', 'Remove')}</button></div>)}
    <div className="flex gap-3 items-center"><button className={ghost} onClick={() => setRows([...rows, { ...blank }])}><Plus size={15} />{tr('إضافة', 'Add')}</button><button className={gold} onClick={save}>{tr('حفظ', 'Save')}</button><span className="text-sm text-champagne-gold">{msg}</span></div></section>
}

export default function Settings() {
  const { tr, L, settings, reloadSettings } = useApp(), [fee, setFee] = useState(''), [brand, setBrand] = useState<any>({}), [msg, setMsg] = useState(''), [err, setErr] = useState('')
  useEffect(() => { setFee(String(settings.delivery_fee ?? '')); setBrand(settings.brand || {}) }, [settings.delivery_fee, settings.brand])
  const saveGeneral = async () => {
    setErr(''); if (fee === '' || Number(fee) < 0) return setErr(tr('أدخل رسوم توصيل صحيحة.', 'Enter a valid delivery fee.'))
    const { error } = await supabase.from('store_settings').upsert([{ key: 'delivery_fee', value: Number(fee) }, { key: 'brand', value: brand }])
    if (error) return setErr(error.message); setMsg(tr('تم الحفظ', 'Saved')); reloadSettings() }
  const { data: cats, reload } = useAsync(async () => (await supabase.from('categories').select('*').order('sort_order')).data || [], [])
  const [nc, setNc] = useState({ name_ar: '', name_en: '', sort_order: '0' })
  const addCat = async () => { if (!nc.name_ar || !nc.name_en) return; const { error } = await supabase.from('categories').insert({ ...nc, slug: slugify(nc.name_en), sort_order: Number(nc.sort_order) || 0 }); if (error) return setErr(error.message); setNc({ name_ar: '', name_en: '', sort_order: '0' }); reload() }
  const delCat = async (id: string) => { if (confirm(tr('حذف الفئة؟', 'Delete category?'))) { await supabase.from('categories').delete().eq('id', id); reload() } }
  const togCat = async (c: any) => { await supabase.from('categories').update({ is_active: !c.is_active }).eq('id', c.id); reload() }
  return <div className="max-w-3xl"><h1 className="font-display text-4xl mb-8">{tr('إعدادات المتجر', 'Store settings')}</h1>
    <section className="glass rounded-xl p-5 mb-6 space-y-4"><h2 className="font-display text-2xl text-champagne-gold">{tr('عام', 'General')}</h2>
      <Field label={tr('رسوم التوصيل (ج.م)', 'Delivery fee (EGP)')}><input type="number" min="0" className={inp} value={fee} onChange={e => setFee(e.target.value)} /></Field>
      <div className="grid sm:grid-cols-2 gap-4"><Field label={tr('اسم العلامة بالعربية', 'Brand name (Arabic)')}><input className={inp} value={brand.name_ar || ''} onChange={e => setBrand({ ...brand, name_ar: e.target.value })} /></Field>
        <Field label={tr('اسم العلامة بالإنجليزية', 'Brand name (English)')}><input dir="ltr" className={inp} value={brand.name_en || ''} onChange={e => setBrand({ ...brand, name_en: e.target.value })} /></Field></div>
      <Field label={tr('قصة العلامة بالعربية', 'Brand story (Arabic)')}><textarea rows={3} className={inp} value={brand.story_ar || ''} onChange={e => setBrand({ ...brand, story_ar: e.target.value })} /></Field>
      <Field label={tr('قصة العلامة بالإنجليزية', 'Brand story (English)')}><textarea rows={3} dir="ltr" className={inp} value={brand.story_en || ''} onChange={e => setBrand({ ...brand, story_en: e.target.value })} /></Field>
      <ErrorBox msg={err} /><div className="flex gap-3 items-center"><button className={gold} onClick={saveGeneral}>{tr('حفظ', 'Save')}</button><span className="text-sm text-champagne-gold">{msg}</span></div></section>
    <section className="glass rounded-xl p-5 mb-6"><h2 className="font-display text-2xl text-champagne-gold mb-4">{tr('الفئات', 'Categories')}</h2>
      {(cats || []).map((c: any) => <div key={c.id} className="flex justify-between items-center py-2 border-b border-white/10 text-sm"><span>{L(c, 'name')} <span className="text-white/35">({c.slug})</span></span>
        <span className="flex gap-3"><button onClick={() => togCat(c)} className="text-xs text-champagne-gold">{c.is_active ? tr('تعطيل', 'Disable') : tr('تفعيل', 'Enable')}</button><button onClick={() => delCat(c.id)} className="text-red-300" aria-label="delete"><Trash2 size={15} /></button></span></div>)}
      <div className="grid sm:grid-cols-4 gap-2 mt-4"><input className={inp} placeholder={tr('الاسم بالعربية', 'Arabic name')} value={nc.name_ar} onChange={e => setNc({ ...nc, name_ar: e.target.value })} />
        <input dir="ltr" className={inp} placeholder="English name" value={nc.name_en} onChange={e => setNc({ ...nc, name_en: e.target.value })} /><input type="number" className={inp} placeholder={tr('الترتيب', 'Order')} value={nc.sort_order} onChange={e => setNc({ ...nc, sort_order: e.target.value })} />
        <button className={gold} onClick={addCat}>{tr('إضافة', 'Add')}</button></div></section>
    <ListEditor k="offers" title={tr('العروض الترويجية (شريط أعلى الموقع)', 'Promotional offers (top bar)')} fields={[['text_ar', 'النص بالعربية', 'Text (Arabic)'], ['text_en', 'النص بالإنجليزية', 'Text (English)']]} blank={{ text_ar: '', text_en: '' }} />
    <ListEditor k="banners" title={tr('لافتات الصفحة الرئيسية', 'Homepage banners')} fields={[['title_ar', 'العنوان بالعربية', 'Title (Arabic)'], ['title_en', 'العنوان بالإنجليزية', 'Title (English)'], ['text_ar', 'النص بالعربية', 'Text (Arabic)'], ['text_en', 'النص بالإنجليزية', 'Text (English)'], ['link', 'الرابط (مثل /shop?x=1)', 'Link (e.g. /shop?x=1)']]} blank={{ title_ar: '', title_en: '', text_ar: '', text_en: '', link: '/shop' }} />
    <ListEditor k="reviews" title={tr('آراء العملاء', 'Customer reviews')} fields={[['name', 'اسم العميل', 'Customer name'], ['rating', 'التقييم (1-5)', 'Rating (1-5)'], ['text_ar', 'التعليق بالعربية', 'Review (Arabic)'], ['text_en', 'التعليق بالإنجليزية', 'Review (English)']]} blank={{ name: '', rating: '5', text_ar: '', text_en: '' }} /></div>
}
