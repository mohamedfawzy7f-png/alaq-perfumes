import { createContext, useContext, useEffect, useState, useCallback, ReactNode } from 'react'
import { supabase } from './supabase'
type Lang = 'ar' | 'en'
const Ctx = createContext<any>(null)
export const useApp = () => useContext(Ctx)
const load = (k: string, d: any) => { try { return JSON.parse(localStorage.getItem(k) || '') } catch { return d } }

export function Providers({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>((localStorage.getItem('alaq_lang') as Lang) || 'ar')
  useEffect(() => {
    document.documentElement.lang = lang; document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr'
    localStorage.setItem('alaq_lang', lang)
  }, [lang])
  const tr = (ar: string, en: string) => (lang === 'ar' ? ar : en)
  const L = (o: any, f: string) => (lang === 'ar' ? o?.[f + '_ar'] || o?.[f + '_en'] : o?.[f + '_en'] || o?.[f + '_ar']) || ''
  const money = (n: number) => new Intl.NumberFormat(lang === 'ar' ? 'ar-EG' : 'en-US').format(Number(n)) + ' ' + tr('ج.م', 'EGP')

  const [cart, setCart] = useState<any[]>(() => load('alaq_cart', []))
  const [wish, setWish] = useState<string[]>(() => load('alaq_wish', []))
  useEffect(() => { localStorage.setItem('alaq_cart', JSON.stringify(cart)) }, [cart])
  useEffect(() => { localStorage.setItem('alaq_wish', JSON.stringify(wish)) }, [wish])
  const addToCart = (p: any, size: number, qty = 1) => setCart(c => {
    const key = p.id + '-' + size, ex = c.find(i => i.key === key)
    if (ex) return c.map(i => i.key === key ? { ...i, qty: Math.min(i.qty + qty, p.stock, 10) } : i)
    return [...c, { key, id: p.id, size, qty: Math.min(qty, p.stock, 10), slug: p.slug, name_ar: p.name_ar, name_en: p.name_en,
      price: p.sale_price ?? p.price, image: p.images?.[0] || '', stock: p.stock }]
  })
  const setQty = (key: string, q: number) => setCart(c => c.map(i => i.key === key ? { ...i, qty: Math.max(1, Math.min(q, i.stock, 10)) } : i))
  const removeItem = (key: string) => setCart(c => c.filter(i => i.key !== key))
  const clearCart = () => setCart([])
  const toggleWish = (id: string) => setWish(w => w.includes(id) ? w.filter(x => x !== id) : [...w, id])

  const [user, setUser] = useState<any>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [authLoading, setAuthLoading] = useState(true)
  useEffect(() => {
    const apply = async (s: any) => {
      const u = s?.user ?? null; setUser(u)
      if (u) { const { data } = await supabase.from('profiles').select('role').eq('id', u.id).maybeSingle(); setIsAdmin(data?.role === 'admin') }
      else setIsAdmin(false)
      setAuthLoading(false)
    }
    supabase.auth.getSession().then(({ data }) => apply(data.session))
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setTimeout(() => apply(s), 0) })
    return () => sub.subscription.unsubscribe()
  }, [])

  const [settings, setSettings] = useState<any>({})
  const reloadSettings = useCallback(async () => {
    const { data } = await supabase.from('store_settings').select('key,value')
    const m: any = {}; data?.forEach((r: any) => { m[r.key] = r.value }); setSettings(m)
  }, [])
  useEffect(() => { reloadSettings() }, [reloadSettings])

  return <Ctx.Provider value={{ lang, setLang, tr, L, money, cart, addToCart, setQty, removeItem, clearCart, wish, toggleWish,
    user, isAdmin, authLoading, settings, reloadSettings, deliveryFee: Number(settings.delivery_fee ?? 0) }}>{children}</Ctx.Provider>
}

export const STATUSES = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled']
export const STATUS_LABEL: any = {
  pending: ['قيد الانتظار', 'Pending'], confirmed: ['مؤكد', 'Confirmed'], processing: ['قيد التجهيز', 'Processing'],
  shipped: ['تم الشحن', 'Shipped'], delivered: ['تم التسليم', 'Delivered'], cancelled: ['ملغي', 'Cancelled'] }
export const GOVS: [string, string][] = [['القاهرة','Cairo'],['الجيزة','Giza'],['الإسكندرية','Alexandria'],['القليوبية','Qalyubia'],['الشرقية','Sharqia'],['الدقهلية','Dakahlia'],['الغربية','Gharbia'],['المنوفية','Monufia'],['البحيرة','Beheira'],['كفر الشيخ','Kafr El Sheikh'],['دمياط','Damietta'],['بورسعيد','Port Said'],['الإسماعيلية','Ismailia'],['السويس','Suez'],['شمال سيناء','North Sinai'],['جنوب سيناء','South Sinai'],['الفيوم','Fayoum'],['بني سويف','Beni Suef'],['المنيا','Minya'],['أسيوط','Asyut'],['سوهاج','Sohag'],['قنا','Qena'],['الأقصر','Luxor'],['أسوان','Aswan'],['البحر الأحمر','Red Sea'],['الوادي الجديد','New Valley'],['مطروح','Matrouh']]
