import { ReactNode, useCallback, useEffect, useState } from 'react'
import { X, Loader2 } from 'lucide-react'
export const inp = 'w-full bg-charcoal-shale border border-white/15 rounded-md px-4 py-3 text-[15px] text-ivory placeholder:text-white/35 focus:border-champagne-gold outline-none'
export const gold = 'inline-flex items-center justify-center gap-2 bg-champagne-gold text-carbon-black font-medium px-7 py-3.5 rounded-full hover:bg-gold-soft transition disabled:opacity-40 disabled:cursor-not-allowed'
export const ghost = 'inline-flex items-center justify-center gap-2 border border-champagne-gold/50 text-champagne-gold px-6 py-3 rounded-full hover:bg-champagne-gold/10 transition disabled:opacity-40'
export const Spinner = () => <div className="flex justify-center py-20"><Loader2 className="animate-spin text-champagne-gold" /></div>
export const Empty = ({ children }: { children: ReactNode }) => <div className="text-center text-white/50 py-16 text-[15px]">{children}</div>
export const ErrorBox = ({ msg }: { msg: string }) => msg ? <div className="rounded-md border border-red-400/40 bg-red-400/10 text-red-200 text-sm p-3">{msg}</div> : null
export const Field = ({ label, children }: { label: string; children: ReactNode }) =>
  <label className="block"><span className="block text-sm text-white/60 mb-1.5">{label}</span>{children}</label>
export function Modal({ onClose, title, children }: { onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => { const h = (e: KeyboardEvent) => e.key === 'Escape' && onClose(); window.addEventListener('keydown', h); return () => window.removeEventListener('keydown', h) }, [])
  return <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6" onClick={onClose}>
    <div className="glass bg-ash/95 w-full sm:max-w-2xl max-h-[92vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl p-5 sm:p-7" onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-5"><h2 className="font-display text-2xl text-champagne-gold">{title}</h2>
        <button onClick={onClose} aria-label="close"><X size={20} /></button></div>{children}</div></div>
}
export function useAsync<T>(fn: () => Promise<T>, deps: any[]) {
  const [data, setData] = useState<T | null>(null), [loading, setLoading] = useState(true), [error, setError] = useState('')
  const run = useCallback(() => { setLoading(true); fn().then(d => { setData(d); setError('') }).catch(e => setError(e.message || String(e))).finally(() => setLoading(false)) }, deps)
  useEffect(run, [run])
  return { data, loading, error, reload: run }
}
export const slugify = (s: string) => s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')
