import { Link, Route, Routes } from 'react-router-dom'
import Shell from './components/Shell'
import Home from './pages/Home'
import Shop from './pages/Shop'
import Product from './pages/Product'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import { Confirmed, Track } from './pages/Order'
import { Login, Wishlist } from './pages/Account'
import AdminLayout, { AdminLogin } from './admin/AdminLayout'
import Dashboard from './admin/Dashboard'
import Products from './admin/Products'
import Orders from './admin/Orders'
import Customers from './admin/Customers'
import Settings from './admin/Settings'
export default function App() {
  return <Routes>
    <Route element={<Shell />}>
      <Route index element={<Home />} /><Route path="shop" element={<Shop />} /><Route path="product/:slug" element={<Product />} />
      <Route path="cart" element={<Cart />} /><Route path="checkout" element={<Checkout />} /><Route path="confirmed/:n" element={<Confirmed />} />
      <Route path="track" element={<Track />} /><Route path="wishlist" element={<Wishlist />} /><Route path="login" element={<Login />} />
      <Route path="*" element={<div className="text-center pt-32">404 <Link to="/" className="text-champagne-gold">Home</Link></div>} /></Route>
    <Route path="admin/login" element={<AdminLogin />} />
    <Route path="admin" element={<AdminLayout />}>
      <Route index element={<Dashboard />} /><Route path="products" element={<Products />} /><Route path="orders" element={<Orders />} />
      <Route path="customers" element={<Customers />} /><Route path="settings" element={<Settings />} /></Route></Routes>
}
