import { useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { CheckCircle2 } from 'lucide-react'
import { useApp, STATUSES, STATUS_LABEL } from '../lib/context'
import { supabase } from '../lib/supabase'
import { gold, ghost, inp, Field, ErrorBox } from '../lib/ui'

export function Confirmed() {
  const { n } = useParams(), { tr } = useApp()
  return <div className="max-w-xl mx-auto px-5 pt-24 text-center"><CheckCircle2 size={56} className="mx-auto text-champagne-gold" />
    <h1 className="font-display text-4xl mt-6">{tr('تم استلام طلبك', 'Order received')}</h1>
    <p className="text-white/60 mt-4">{tr('رقم طلبك', 'Your order number')}</p><div className="text-3xl text-champagne-gold mt-1 tracking-wider" dir="ltr">{n}</div>
    <p className="text-white/55 text-sm mt-5 leading-7">{tr('احتفظ بالرقم لتتبع الطلب. سنتواصل معك على هاتفك لتأكيده. الدفع عند الاستلام.', 'Keep this number to track your order. We will call you to confirm. Pay on delivery.')}</p>
    <div className="mt-8 flex gap-3 justify-center"><Link to={`/track?n=${n}`} className={gold}>{tr('تتبع الطلب', 'Track order')}</Link><Link to="/shop" className={ghost}>{tr('متابعة التسوق', 'Continue shopping')}</Link></div></div>
}

export function Track() {
  const { tr, L, money, lang } = useApp(), [sp] = useSearchParams()
  const [num, setNum] = useState(sp.get('n') || ''), [phone, setPhone] = useState(sessionStorage.getItem('alaq_last_phone') || '')
  const [o, setO] = useState<any>(null), [err, setErr] = useState('')
  const go = async (e: any) => {
    e.preventDefault(); setErr(''); setO(null)
    const { data, error } = await supabase.rpc('track_order', { p_number: num.trim().toUpperCase(), p_phone: phone.replace(/[\s-]/g, '') })
    if (error) return setErr(error.message); if (!data) return setErr(tr('لم نجد طلباً بهذه البيانات.', 'No order found with these details.')); setO(data)
  }
  const idx = o ? STATUSES.indexOf(o.status) : -1
  return <div className="max-w-xl mx-auto px-5 pt-14"><h1 className="font-display text-4xl mb-8">{tr('تتبع الطلب', 'Track your order')}</h1>
    <form onSubmit={go} className="space-y-4"><Field label={tr('رقم الطلب', 'Order number')}><input required dir="ltr" className={inp} value={num} onChange={e => setNum(e.target.value)} placeholder="ALQ-1001" /></Field>
      <Field label={tr('رقم الهاتف', 'Phone number')}><input required dir="ltr" inputMode="tel" className={inp} value={phone} onChange={e => setPhone(e.target.value)} placeholder="01XXXXXXXXX" /></Field>
      <ErrorBox msg={err} /><button className={gold + ' w-full'}>{tr('تتبع', 'Track')}</button></form>
    {o && <div className="glass rounded-2xl p-6 mt-8"><div className="flex justify-between"><span dir="ltr" className="text-champagne-gold">{o.order_number}</span><span>{money(o.total)}</span></div>
      {o.status === 'cancelled' ? <div className="mt-5 text-red-300">{STATUS_LABEL.cancelled[lang === 'ar' ? 0 : 1]}</div> :
        <ol className="mt-6 space-y-3">{STATUSES.filter(s => s !== 'cancelled').map((s, i) => <li key={s} className={`flex items-center gap-3 text-sm ${i <= idx ? 'text-champagne-gold' : 'text-white/35'}`}>
          <span className={`w-3 h-3 rounded-full ${i <= idx ? 'bg-champagne-gold' : 'border border-white/30'}`} />{STATUS_LABEL[s][lang === 'ar' ? 0 : 1]}</li>)}</ol>}
      <div className="mt-6 pt-4 border-t border-white/10 text-sm text-white/65 space-y-1">{o.items.map((i: any, k: number) => <div key={k}>{L(i, 'name')} × {i.quantity}</div>)}</div></div>}</div>
}
