import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { gold, ghost, inp, Field, ErrorBox, useAsync, Spinner, Empty } from '../lib/ui'
import ProductCard from '../components/ProductCard'

export function Login() {
  const { tr, user, isAdmin } = useApp(), [mode, setMode] = useState<'in' | 'up'>('in')
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [name, setName] = useState(''), [err, setErr] = useState(''), [info, setInfo] = useState('')
  const submit = async (e: any) => {
    e.preventDefault(); setErr(''); setInfo('')
    if (mode === 'up') {
      const { data, error } = await supabase.auth.signUp({ email, password: pw, options: { data: { full_name: name } } })
      if (error) return setErr(error.message)
      setInfo(data.session ? tr('تم إنشاء الحساب.', 'Account created.') : tr('تحقق من بريدك الإلكتروني لتأكيد الحساب.', 'Check your email to confirm your account.'))
    } else { const { error } = await supabase.auth.signInWithPassword({ email, password: pw }); if (error) setErr(error.message) }
  }
  if (user) return <div className="max-w-md mx-auto px-5 pt-20 text-center"><h1 className="font-display text-4xl mb-3">{tr('حسابي', 'My account')}</h1><p className="text-white/60 mb-8" dir="ltr">{user.email}</p>
    <div className="flex flex-col gap-3">{isAdmin && <Link to="/admin" className={gold}>{tr('لوحة التحكم', 'Admin dashboard')}</Link>}<Link to="/track" className={ghost}>{tr('تتبع طلب', 'Track an order')}</Link>
      <button className={ghost} onClick={() => supabase.auth.signOut()}>{tr('تسجيل الخروج', 'Sign out')}</button></div></div>
  return <form onSubmit={submit} className="max-w-md mx-auto px-5 pt-16 space-y-4"><h1 className="font-display text-4xl mb-4">{mode === 'in' ? tr('تسجيل الدخول', 'Sign in') : tr('إنشاء حساب', 'Create account')}</h1>
    {mode === 'up' && <Field label={tr('الاسم', 'Name')}><input required className={inp} value={name} onChange={e => setName(e.target.value)} /></Field>}
    <Field label={tr('البريد الإلكتروني', 'Email')}><input required type="email" dir="ltr" className={inp} value={email} onChange={e => setEmail(e.target.value)} /></Field>
    <Field label={tr('كلمة المرور', 'Password')}><input required minLength={8} type="password" dir="ltr" className={inp} value={pw} onChange={e => setPw(e.target.value)} /></Field>
    <ErrorBox msg={err} />{info && <div className="text-champagne-gold text-sm">{info}</div>}
    <button className={gold + ' w-full'}>{mode === 'in' ? tr('دخول', 'Sign in') : tr('إنشاء الحساب', 'Create account')}</button>
    <button type="button" className="text-sm text-champagne-gold w-full" onClick={() => setMode(mode === 'in' ? 'up' : 'in')}>{mode === 'in' ? tr('ليس لديك حساب؟ أنشئ حساباً', 'No account? Create one') : tr('لديك حساب؟ سجّل الدخول', 'Have an account? Sign in')}</button></form>
}

export function Wishlist() {
  const { tr, wish } = useApp()
  const { data, loading } = useAsync(async () => wish.length ? (await supabase.from('products').select('*').in('id', wish).eq('is_active', true)).data || [] : [], [wish.join(',')])
  return <div className="max-w-7xl mx-auto px-5 pt-12"><h1 className="font-display text-4xl mb-8">{tr('المفضلة', 'Wishlist')}</h1>
    {loading ? <Spinner /> : !data?.length ? <Empty>{tr('لم تضف أي عطر للمفضلة بعد.', 'Your wishlist is empty.')}</Empty> :
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">{data.map((p: any) => <ProductCard key={p.id} p={p} />)}</div>}</div>
}
