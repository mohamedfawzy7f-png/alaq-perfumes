import { useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, inp, Spinner, Empty, ErrorBox } from '../lib/ui'
import ProductCard from '../components/ProductCard'

export default function Shop() {
  const { tr, L } = useApp(), [sp, setSp] = useSearchParams()
  const q = sp.get('q') || '', cat = sp.get('cat') || '', g = sp.get('g') || '', t = sp.get('t') || '', x = sp.get('x') || '', sort = sp.get('sort') || 'new'
  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n) }
  const { data: all, loading, error } = useAsync(async () => {
    const { data, error } = await supabase.from('products').select('*, categories(slug)').eq('is_active', true).order('created_at', { ascending: false }); if (error) throw error; return data }, [])
  const { data: cats } = useAsync(async () => (await supabase.from('categories').select('*').eq('is_active', true).order('sort_order')).data || [], [])
  const types = useMemo(() => [...new Set((all || []).map((p: any) => p.fragrance_type).filter(Boolean))] as string[], [all])
  const list = useMemo(() => {
    let r = (all || []).filter((p: any) =>
      (!q || [p.name_ar, p.name_en, p.fragrance_type, p.description_ar, p.description_en].join(' ').toLowerCase().includes(q.toLowerCase())) &&
      (!cat || p.categories?.slug === cat) && (!g || p.gender === g) && (!t || p.fragrance_type === t) && (!x || p.is_exclusive))
    const pr = (p: any) => p.sale_price ?? p.price
    if (sort === 'asc') r = [...r].sort((a, b) => pr(a) - pr(b)); if (sort === 'desc') r = [...r].sort((a, b) => pr(b) - pr(a))
    return r }, [all, q, cat, g, t, x, sort])
  return <div className="max-w-7xl mx-auto px-5 pt-12">
    <h1 className="font-display text-4xl sm:text-5xl mb-8">{tr('المتجر', 'Shop')}</h1>
    <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-10">
      <input className={inp + ' col-span-2 md:col-span-1'} placeholder={tr('بحث', 'Search')} value={q} onChange={e => set('q', e.target.value)} />
      <select className={inp} value={cat} onChange={e => set('cat', e.target.value)}><option value="">{tr('كل الفئات', 'All categories')}</option>{(cats || []).map((c: any) => <option key={c.id} value={c.slug}>{L(c, 'name')}</option>)}</select>
      <select className={inp} value={g} onChange={e => set('g', e.target.value)}><option value="">{tr('الكل', 'Everyone')}</option><option value="men">{tr('رجالي', 'Men')}</option><option value="women">{tr('نسائي', 'Women')}</option><option value="unisex">{tr('للجنسين', 'Unisex')}</option></select>
      <select className={inp} value={t} onChange={e => set('t', e.target.value)}><option value="">{tr('كل العائلات العطرية', 'All fragrance types')}</option>{types.map(v => <option key={v}>{v}</option>)}</select>
      <select className={inp} value={sort} onChange={e => set('sort', e.target.value)}><option value="new">{tr('الأحدث', 'Newest')}</option><option value="asc">{tr('السعر: الأقل', 'Price: low to high')}</option><option value="desc">{tr('السعر: الأعلى', 'Price: high to low')}</option></select></div>
    <ErrorBox msg={error} />
    {loading ? <Spinner /> : list.length === 0 ? <Empty>{tr('لا توجد منتجات مطابقة.', 'No matching products.')}</Empty> :
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">{list.map((p: any) => <ProductCard key={p.id} p={p} />)}</div>}</div>
}
