import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { Heart, Minus, Plus } from 'lucide-react'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, gold, ghost, Spinner, Empty } from '../lib/ui'
import ProductCard from '../components/ProductCard'

export default function Product() {
  const { slug } = useParams(), { tr, L, money, addToCart, wish, toggleWish } = useApp(), nav = useNavigate()
  const { data: p, loading } = useAsync(async () => (await supabase.from('products').select('*, categories(name_ar,name_en)').eq('slug', slug).eq('is_active', true).maybeSingle()).data, [slug])
  const { data: related } = useAsync(async () => p ? (await supabase.from('products').select('*').eq('is_active', true).neq('id', p.id)
    .or(p.category_id ? `category_id.eq.${p.category_id},gender.eq.${p.gender}` : `gender.eq.${p.gender}`).limit(4)).data || [] : [], [p?.id])
  const [img, setImg] = useState(0), [size, setSize] = useState(0), [qty, setQty] = useState(1), [added, setAdded] = useState(false)
  useEffect(() => { if (p) { setSize(p.sizes?.[0] || 0); setImg(0); setQty(1) } }, [p?.id])
  if (loading) return <Spinner />
  if (!p) return <Empty>{tr('المنتج غير موجود.', 'Product not found.')} <Link className="text-champagne-gold" to="/shop">{tr('العودة للمتجر', 'Back to shop')}</Link></Empty>
  const out = p.stock <= 0, price = p.sale_price ?? p.price
  const add = () => { addToCart(p, size, qty); setAdded(true); setTimeout(() => setAdded(false), 1800) }
  return <div className="max-w-7xl mx-auto px-5 pt-10">
    <div className="grid md:grid-cols-2 gap-10 lg:gap-16">
      <div><div className="aspect-[4/5] glass rounded-2xl overflow-hidden">{p.images?.[img] && <img src={p.images[img]} alt={L(p, 'name')} className="w-full h-full object-cover" />}</div>
        {p.images?.length > 1 && <div className="flex gap-3 mt-3 overflow-x-auto">{p.images.map((u: string, i: number) =>
          <button key={u} onClick={() => setImg(i)} className={`w-20 h-24 shrink-0 rounded-lg overflow-hidden border ${i === img ? 'border-champagne-gold' : 'border-white/10'}`}><img src={u} alt="" className="w-full h-full object-cover" /></button>)}</div>}</div>
      <div>
        <div className="text-sm text-champagne-gold">{L(p.categories, 'name')} {p.fragrance_type && `• ${p.fragrance_type}`}</div>
        <h1 className="font-display text-4xl sm:text-5xl mt-2">{L(p, 'name')}</h1>
        <div className="text-2xl text-champagne-gold mt-5">{money(price)}{p.sale_price && <span className="text-white/40 line-through text-lg ms-3">{money(p.price)}</span>}</div>
        <p className="text-white/65 leading-8 mt-6 whitespace-pre-line">{L(p, 'description')}</p>
        <div className="mt-8"><div className="text-sm text-white/55 mb-2">{tr('الحجم', 'Size')}</div>
          <div className="flex gap-2 flex-wrap">{(p.sizes || []).map((s: number) => <button key={s} onClick={() => setSize(s)}
            className={`px-5 py-2 rounded-full border text-sm ${s === size ? 'border-champagne-gold text-champagne-gold' : 'border-white/20 text-white/70'}`}>{s} {tr('مل', 'ml')}</button>)}</div></div>
        <div className="mt-4 text-sm">{out ? <span className="text-red-300">{tr('نفد المخزون', 'Out of stock')}</span> : p.stock <= 5 ? <span className="text-gold-soft">{tr(`متبقي ${p.stock} فقط`, `Only ${p.stock} left`)}</span> : <span className="text-white/55">{tr('متوفر', 'In stock')}</span>}</div>
        <div className="mt-8 flex items-center gap-3 flex-wrap">
          <div className="flex items-center glass rounded-full"><button className="p-3" onClick={() => setQty(Math.max(1, qty - 1))} aria-label="-"><Minus size={16} /></button>
            <span className="w-8 text-center">{qty}</span><button className="p-3" onClick={() => setQty(Math.min(Math.min(p.stock, 10), qty + 1))} aria-label="+"><Plus size={16} /></button></div>
          <button disabled={out} onClick={add} className={gold}>{added ? tr('تمت الإضافة ✓', 'Added ✓') : tr('أضف إلى السلة', 'Add to cart')}</button>
          <button onClick={() => toggleWish(p.id)} className="w-12 h-12 rounded-full border border-white/20 grid place-items-center" aria-label="wishlist"><Heart size={18} className={wish.includes(p.id) ? 'fill-champagne-gold text-champagne-gold' : ''} /></button></div>
        <button disabled={out} onClick={() => { addToCart(p, size, qty); nav('/checkout') }} className={ghost + ' mt-4'}>{tr('اشترِ الآن', 'Buy now')}</button></div></div>
    {related && related.length > 0 && <section className="mt-24"><h2 className="font-display text-3xl mb-8">{tr('قد يعجبك أيضاً', 'You may also like')}</h2>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">{related.map((r: any) => <ProductCard key={r.id} p={r} />)}</div></section>}</div>
}
