import { Link } from 'react-router-dom'
import { Minus, Plus, Trash2, Droplet } from 'lucide-react'
import { useApp } from '../lib/context'
import { gold, Empty } from '../lib/ui'
export default function Cart() {
  const { tr, L, money, cart, setQty, removeItem, deliveryFee } = useApp()
  const sub = cart.reduce((a: number, i: any) => a + i.price * i.qty, 0)
  if (!cart.length) return <div className="max-w-3xl mx-auto px-5 pt-20 text-center"><Empty>{tr('سلتك فارغة.', 'Your cart is empty.')}</Empty><Link to="/shop" className={gold}>{tr('تصفح العطور', 'Browse perfumes')}</Link></div>
  return <div className="max-w-5xl mx-auto px-5 pt-12 grid lg:grid-cols-3 gap-10">
    <div className="lg:col-span-2"><h1 className="font-display text-4xl mb-8">{tr('سلة التسوق', 'Shopping cart')}</h1>
      {cart.map((i: any) => <div key={i.key} className="flex gap-4 py-5 border-b border-white/10">
        <Link to={`/product/${i.slug}`} className="w-20 h-24 glass rounded-lg overflow-hidden shrink-0 grid place-items-center">{i.image ? <img src={i.image} alt="" className="w-full h-full object-cover" /> : <Droplet className="text-champagne-gold/40" />}</Link>
        <div className="flex-1"><div className="font-display text-xl">{L(i, 'name')}</div><div className="text-sm text-white/50">{i.size} {tr('مل', 'ml')}</div>
          <div className="flex items-center gap-3 mt-3"><div className="flex items-center glass rounded-full"><button className="p-2" onClick={() => setQty(i.key, i.qty - 1)} aria-label="-"><Minus size={14} /></button><span className="w-6 text-center text-sm">{i.qty}</span><button className="p-2" onClick={() => setQty(i.key, i.qty + 1)} aria-label="+"><Plus size={14} /></button></div>
            <button onClick={() => removeItem(i.key)} aria-label="remove" className="text-white/50 hover:text-red-300"><Trash2 size={16} /></button></div></div>
        <div className="text-champagne-gold">{money(i.price * i.qty)}</div></div>)}</div>
    <aside className="glass rounded-2xl p-6 h-fit"><h2 className="font-display text-2xl mb-5">{tr('ملخص الطلب', 'Order summary')}</h2>
      <div className="flex justify-between text-sm py-2"><span className="text-white/60">{tr('المجموع', 'Subtotal')}</span><span>{money(sub)}</span></div>
      <div className="flex justify-between text-sm py-2"><span className="text-white/60">{tr('رسوم التوصيل', 'Delivery')}</span><span>{money(deliveryFee)}</span></div>
      <div className="flex justify-between py-4 mt-2 border-t border-white/10 text-lg"><span>{tr('الإجمالي', 'Total')}</span><span className="text-champagne-gold">{money(sub + deliveryFee)}</span></div>
      <Link to="/checkout" className={gold + ' w-full'}>{tr('إتمام الطلب', 'Checkout')}</Link></aside></div>
}
