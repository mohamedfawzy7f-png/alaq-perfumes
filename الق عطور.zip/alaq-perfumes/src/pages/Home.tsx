import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Banknote, Truck, PackageSearch } from 'lucide-react'
import { useApp } from '../lib/context'
import { supabase } from '../lib/supabase'
import { useAsync, gold, ghost, inp, Spinner } from '../lib/ui'
import ProductCard from '../components/ProductCard'

function Shelf({ title, items, to }: any) {
  const { tr } = useApp()
  if (!items.length) return null
  return <section className="max-w-7xl mx-auto px-5 mt-24">
    <div className="flex items-end justify-between mb-8"><h2 className="font-display text-3xl sm:text-4xl">{title}</h2>
      <Link to={to} className="text-sm text-champagne-gold">{tr('عرض الكل', 'View all')}</Link></div>
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-10">{items.slice(0, 4).map((p: any) => <ProductCard key={p.id} p={p} />)}</div></section>
}

export default function Home() {
  const { tr, L, settings } = useApp()
  const { data: prods, loading } = useAsync(async () => {
    const { data, error } = await supabase.from('products').select('*').eq('is_active', true).order('created_at', { ascending: false }); if (error) throw error; return data }, [])
  const { data: cats } = useAsync(async () => (await supabase.from('categories').select('*').eq('is_active', true).order('sort_order')).data || [], [])
  const [email, setEmail] = useState(''), [msg, setMsg] = useState('')
  const subscribe = async (e: any) => {
    e.preventDefault()
    const { error } = await supabase.from('newsletter_subscribers').insert({ email: email.trim() })
    setMsg(!error || error.code === '23505' ? tr('تم الاشتراك. شكراً لك.', 'You are subscribed. Thank you.') : tr('تعذر الاشتراك. تحقق من البريد الإلكتروني.', 'Could not subscribe. Check the email address.'))
    if (!error) setEmail('')
  }
  const P = prods || [], f = (k: string) => P.filter((p: any) => p[k]), g = (v: string) => P.filter((p: any) => p.gender === v)
  const reviews = settings.reviews || [], banners = settings.banners || []
  const story = L(settings.brand || {}, 'story') || tr('وُلد أَلَق من شغف بالعطور الشرقية والتفاصيل الهادئة. كل عطر يُختار بعناية ليُرافقك طوال اليوم.', 'ALAQ was born from a love of oriental fragrance and quiet detail. Every scent is chosen to stay with you through the day.')
  return <div>
    <section className="relative min-h-[88vh] halo flex items-center overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 py-16 grid lg:grid-cols-2 gap-14 items-center w-full">
        <div className="rise">
          <h1 className="font-display text-5xl sm:text-7xl leading-[1.15]">{tr('عطرٌ يترك أثره', 'A fragrance that leaves its mark')}</h1>
          <p className="mt-6 text-white/60 max-w-md leading-8 text-[17px]">{tr('عطور فاخرة بتركيبات هادئة وثبات طويل، تصل إلى بابك في كل أنحاء مصر.', 'Luxury perfumes with quiet compositions and lasting presence, delivered to your door across Egypt.')}</p>
          <div className="mt-9 flex gap-3 flex-wrap"><Link to="/shop" className={gold}>{tr('تسوق الآن', 'Shop now')}</Link>
            <Link to="/shop?x=1" className={ghost}>{tr('المجموعة الحصرية', 'Exclusive collection')}</Link></div></div>
        <div className="flex justify-center"><img src={import.meta.env.BASE_URL + 'logo.png'} alt="ALAQ Perfumes" className="box3d w-72 sm:w-96 rounded-2xl bg-ivory" /></div></div></section>

    {banners.length > 0 && <section className="max-w-7xl mx-auto px-5 grid gap-4 md:grid-cols-2 mt-6">
      {banners.map((b: any, i: number) => <a key={i} href={'#' + (b.link || '/shop')} className="glass rounded-xl p-6 block hover:border-champagne-gold/60 transition">
        <div className="font-display text-2xl text-champagne-gold">{L(b, 'title')}</div><p className="text-white/60 mt-2 text-sm leading-7">{L(b, 'text')}</p></a>)}</section>}

    {cats && cats.length > 0 && <section className="max-w-7xl mx-auto px-5 mt-24">
      <h2 className="font-display text-3xl sm:text-4xl mb-8">{tr('المجموعات', 'Collections')}</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{cats.map((c: any) => <Link key={c.id} to={`/shop?cat=${c.slug}`}
        className="glass rounded-xl py-10 text-center font-display text-2xl hover:text-champagne-gold transition">{L(c, 'name')}</Link>)}</div></section>}

    {loading ? <Spinner /> : P.length === 0 ? <p className="text-center text-white/50 mt-24">{tr('المجموعة قريباً.', 'The collection is coming soon.')}</p> : <>
      <Shelf title={tr('مختارات مميزة', 'Featured')} items={f('is_featured')} to="/shop" />
      <Shelf title={tr('الأكثر مبيعاً', 'Best sellers')} items={f('is_bestseller')} to="/shop" />
      <Shelf title={tr('وصل حديثاً', 'New arrivals')} items={f('is_new')} to="/shop" />
      <Shelf title={tr('عطور رجالية', "Men's perfumes")} items={g('men')} to="/shop?g=men" />
      <Shelf title={tr('عطور نسائية', "Women's perfumes")} items={g('women')} to="/shop?g=women" />
      <Shelf title={tr('عطور للجنسين', 'Unisex perfumes')} items={g('unisex')} to="/shop?g=unisex" />
      <Shelf title={tr('المجموعة الحصرية', 'Exclusive collection')} items={f('is_exclusive')} to="/shop?x=1" /></>}

    <section className="max-w-7xl mx-auto px-5 mt-28">
      <h2 className="font-display text-3xl sm:text-4xl mb-8">{tr('لماذا أَلَق', 'Why ALAQ')}</h2>
      <div className="grid md:grid-cols-3 gap-4">{[
        [Banknote, tr('الدفع عند الاستلام', 'Cash on delivery'), tr('لا تدفع إلا عند وصول طلبك.', 'Pay only when your order arrives.')],
        [Truck, tr('توصيل لكل المحافظات', 'Delivery nationwide'), tr('نوصّل إلى جميع محافظات مصر.', 'We deliver to every Egyptian governorate.')],
        [PackageSearch, tr('تتبع طلبك', 'Track your order'), tr('تابع حالة الطلب برقم الطلب ورقم هاتفك.', 'Follow your order with its number and your phone.')]]
        .map(([Icon, t, d]: any, i) => <div key={i} className="glass rounded-xl p-7"><Icon className="text-champagne-gold mb-4" /><div className="font-display text-xl">{t}</div><p className="text-white/55 text-sm mt-2 leading-7">{d}</p></div>)}</div></section>

    <section className="max-w-3xl mx-auto px-5 mt-28 text-center"><h2 className="font-display text-3xl sm:text-4xl mb-6">{tr('قصتنا', 'Our story')}</h2>
      <p className="text-white/65 leading-9 text-[17px]">{story}</p></section>

    {reviews.length > 0 && <section className="max-w-7xl mx-auto px-5 mt-28"><h2 className="font-display text-3xl sm:text-4xl mb-8">{tr('آراء العملاء', 'Customer reviews')}</h2>
      <div className="grid md:grid-cols-3 gap-4">{reviews.map((r: any, i: number) => <figure key={i} className="glass rounded-xl p-7">
        <div className="text-champagne-gold mb-3">{'★'.repeat(Number(r.rating) || 5)}</div><blockquote className="text-white/70 leading-8 text-[15px]">{L(r, 'text')}</blockquote>
        <figcaption className="mt-4 text-sm text-champagne-gold">{r.name}</figcaption></figure>)}</div></section>}

    <section className="max-w-xl mx-auto px-5 mt-28 text-center"><h2 className="font-display text-3xl mb-3">{tr('النشرة البريدية', 'Newsletter')}</h2>
      <p className="text-white/55 text-sm mb-6">{tr('اشترك ليصلك جديد العطور والعروض.', 'Subscribe for new fragrances and offers.')}</p>
      <form onSubmit={subscribe} className="flex gap-2"><input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder={tr('بريدك الإلكتروني', 'Your email')} className={inp + ' rounded-full'} />
        <button className={gold}>{tr('اشترك', 'Subscribe')}</button></form>{msg && <p className="mt-4 text-sm text-champagne-gold">{msg}</p>}</section>
  </div>
}
