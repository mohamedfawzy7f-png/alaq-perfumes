import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useApp, GOVS } from '../lib/context'
import { supabase } from '../lib/supabase'
import { gold, inp, Field, ErrorBox, Empty } from '../lib/ui'

export default function Checkout() {
  const { tr, lang, L, money, cart, clearCart, deliveryFee } = useApp(), nav = useNavigate()
  const [f, setF] = useState({ full_name: '', phone: '', governorate: '', city: '', address: '', notes: '' }), [err, setErr] = useState(''), [busy, setBusy] = useState(false)
  const sub = cart.reduce((a: number, i: any) => a + i.price * i.qty, 0)
  if (!cart.length) return <div className="max-w-3xl mx-auto px-5 pt-20 text-center"><Empty>{tr('سلتك فارغة.', 'Your cart is empty.')}</Empty><Link to="/shop" className={gold}>{tr('تصفح العطور', 'Browse perfumes')}</Link></div>
  const up = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value })
  const submit = async (e: any) => {
    e.preventDefault(); setErr('')
    const phone = f.phone.replace(/[\s-]/g, '')
    if (!/^01[0-25][0-9]{8}$/.test(phone)) return setErr(tr('أدخل رقم موبايل مصري صحيح (11 رقماً يبدأ بـ 01).', 'Enter a valid Egyptian mobile number (11 digits starting with 01).'))
    if (f.full_name.trim().length < 3) return setErr(tr('أدخل الاسم الكامل.', 'Enter your full name.'))
    if (f.address.trim().length < 8) return setErr(tr('أدخل العنوان بالتفصيل.', 'Enter your full address.'))
    setBusy(true)
    const { data, error } = await supabase.rpc('place_order', { payload: { customer: { ...f, phone }, items: cart.map((i: any) => ({ product_id: i.id, quantity: i.qty, size_ml: i.size })) } })
    setBusy(false)
    if (error) return setErr(error.message.includes('insufficient stock') ? tr('الكمية المطلوبة غير متوفرة لأحد المنتجات. عدّل السلة وحاول مجدداً.', 'Not enough stock for one item. Update your cart and try again.') : tr('تعذر إتمام الطلب. حاول مرة أخرى.', 'Could not place the order. Please try again.') + ' (' + error.message + ')')
    clearCart(); sessionStorage.setItem('alaq_last_phone', phone); nav(`/confirmed/${data}`)
  }
  return <form onSubmit={submit} className="max-w-5xl mx-auto px-5 pt-12 grid lg:grid-cols-5 gap-10">
    <div className="lg:col-span-3 space-y-4"><h1 className="font-display text-4xl mb-4">{tr('إتمام الطلب', 'Checkout')}</h1>
      <Field label={tr('الاسم الكامل', 'Full name')}><input required className={inp} value={f.full_name} onChange={up('full_name')} autoComplete="name" /></Field>
      <Field label={tr('رقم الهاتف', 'Phone number')}><input required inputMode="tel" dir="ltr" className={inp} value={f.phone} onChange={up('phone')} placeholder="01XXXXXXXXX" autoComplete="tel" /></Field>
      <div className="grid sm:grid-cols-2 gap-4">
        <Field label={tr('المحافظة', 'Governorate')}><select required className={inp} value={f.governorate} onChange={up('governorate')}><option value="">—</option>{GOVS.map(([a, e]) => <option key={e} value={lang === 'ar' ? a : e}>{lang === 'ar' ? a : e}</option>)}</select></Field>
        <Field label={tr('المدينة', 'City')}><input required className={inp} value={f.city} onChange={up('city')} /></Field></div>
      <Field label={tr('العنوان بالتفصيل', 'Full address')}><textarea required rows={3} className={inp} value={f.address} onChange={up('address')} /></Field>
      <Field label={tr('ملاحظات إضافية (اختياري)', 'Additional notes (optional)')}><textarea rows={2} className={inp} value={f.notes} onChange={up('notes')} /></Field>
      <div className="glass rounded-xl p-4 text-sm">{tr('طريقة الدفع: الدفع عند الاستلام', 'Payment method: Cash on delivery')}</div></div>
    <aside className="lg:col-span-2 glass rounded-2xl p-6 h-fit"><h2 className="font-display text-2xl mb-4">{tr('ملخص الطلب', 'Order summary')}</h2>
      {cart.map((i: any) => <div key={i.key} className="flex justify-between text-sm py-2 gap-3"><span className="text-white/70">{L(i, 'name')} · {i.size}{tr('مل', 'ml')} × {i.qty}</span><span>{money(i.price * i.qty)}</span></div>)}
      <div className="flex justify-between text-sm py-2 border-t border-white/10 mt-2"><span className="text-white/60">{tr('رسوم التوصيل', 'Delivery')}</span><span>{money(deliveryFee)}</span></div>
      <div className="flex justify-between py-3 text-lg"><span>{tr('الإجمالي', 'Total')}</span><span className="text-champagne-gold">{money(sub + deliveryFee)}</span></div>
      <ErrorBox msg={err} /><button disabled={busy} className={gold + ' w-full mt-4'}>{busy ? tr('جارٍ الإرسال...', 'Placing order...') : tr('تأكيد الطلب', 'Place order')}</button></aside></form>
}
