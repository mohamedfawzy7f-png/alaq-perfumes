import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
// base './' lets the build work on GitHub Pages sub-paths; the app uses HashRouter.
export default defineConfig({ base: './', plugins: [react(), tailwindcss()] })
